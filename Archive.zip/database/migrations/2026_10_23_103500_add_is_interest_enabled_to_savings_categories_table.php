<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('savings_categories', function (Blueprint $table) {
            $table->boolean('is_interest_enabled')->default(true)->after('default_annual_rate');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('savings_categories', function (Blueprint $table) {
            $table->dropColumn('is_interest_enabled');
        });
    }
};
